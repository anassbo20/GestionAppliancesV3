package com.example.gestion_appliances_v2.bean;

import java.util.Date;

public interface Archivable {

public Boolean getArchive() ;

public void setArchive(Boolean archive);

public Date getDateArchivage() ;

public void setDateArchivage(Date dateArchivage) ;

}
