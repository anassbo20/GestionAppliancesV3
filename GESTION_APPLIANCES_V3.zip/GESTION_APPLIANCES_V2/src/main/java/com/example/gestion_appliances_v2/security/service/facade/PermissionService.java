package com.example.gestion_appliances_v2.security.service.facade;


import com.example.gestion_appliances_v2.security.bean.Permission;


public interface PermissionService {
    public Permission save(Permission permission);
}
