package com.example.gestion_appliances_v2.security.common;

public interface SecurityParams {
    public static final String JWT_HEADER_NAME="Authorization";
    public static final String SECRET="b36d9f84-e0e9-4a3f-94ca-c18a6046eef2";
    public static final long EXPIRATION=86400000;
    public static final String HEADER_PREFIX="Bearer ";

}
