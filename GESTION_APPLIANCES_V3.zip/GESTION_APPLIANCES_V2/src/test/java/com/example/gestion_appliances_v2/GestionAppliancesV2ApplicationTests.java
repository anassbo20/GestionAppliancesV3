package com.example.gestion_appliances_v2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionAppliancesV2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
